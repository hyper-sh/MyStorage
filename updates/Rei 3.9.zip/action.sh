PKGNAME=com.rei.subs
CLASSPATH=com.rei.subs.app.MainActivity

am start -n $PKGNAME/$CLASSPATH