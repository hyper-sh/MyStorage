cmd overlay fabricate --target android --name ReiComponentcolorAccentPrimary android:color/holo_blue_light 0x1c 0xFF50A6D7
cmd overlay enable --user current com.android.shell:ReiComponentcolorAccentPrimary
cmd overlay fabricate --target android --name ReiComponentcolorAccentSecondary android:color/holo_green_light 0x1c 0xFF387BFF
cmd overlay enable --user current com.android.shell:ReiComponentcolorAccentSecondary
cmd overlay fabricate --target android --name ReiComponentquick_qs_offset_height android:dimen/quick_qs_offset_height 0x05 61953
cmd overlay enable --user current com.android.shell:ReiComponentquick_qs_offset_height
cmd overlay fabricate --target com.android.systemui --name ReiComponentqqs_layout_margin_top com.android.systemui:dimen/qqs_layout_margin_top 0x05 61953
cmd overlay enable --user current com.android.shell:ReiComponentqqs_layout_margin_top
cmd overlay fabricate --target com.android.systemui --name ReiComponentqs_header_row_min_height com.android.systemui:dimen/qs_header_row_min_height 0x05 61953
cmd overlay enable --user current com.android.shell:ReiComponentqs_header_row_min_height
